import { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  FlatList,
  StyleSheet,
} from 'react-native';

const ShoppingList = () => {
  const [itemInput, setItemInput] = useState('');
  const [shoppingList, setShoppingList] = useState([]);
  const addItem = () => {
    if (itemInput.trim() !== '') {
      setShoppingList([...shoppingList, itemInput]);
      setItemInput('');
    }
  };

  const deleteItem = (index) => {
    const updatedList = [...shoppingList];
    updatedList.splice(index, 1);
    setShoppingList(updatedList);
  };

  const renderItem = ({ item, index }) => (
    <View style={styles.itemContainer}>
      <Text style={styles.itemText}>{item}</Text>
      <Button title="Delete" onPress={() => deleteItem(index)} />
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Shopping List</Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter item name"
          value={itemInput}
          onChangeText={setItemInput}
        />
        <Button title="Add" onPress={addItem} />
      </View>
      <FlatList
        data={shoppingList}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
        style={styles.list}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  input: {
    flex: 1,
    height: 40,
    marginRight: 8,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 8,
  },
  list: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  itemText: {
    flex: 1,
    fontSize: 16,
  },
});

export default ShoppingList;
